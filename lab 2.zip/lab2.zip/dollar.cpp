
//mokhtari,Zahra

//Tejas, Bhartiya 

//07/8/2022 

//This lab is being solved by a team of people 

//Lab 2 this code is showing  Currency Simulator




#ifndef DOLLAR_H
#define DOLLAR_H

#include <iostream>
#include "currency.cpp"
using namespace std;

// derived class Dollar from Currency class
class Dollar : public Currency
{

    private:
        string currencyName;
    
    public:
        Dollar()
        {
            currencyName = "dollar";
        }
    
        Dollar(double value) : Currency(value)
        {
            currencyName = "Dollar";
        }
    
        void toString()
        {
            Currency::toString();
            cout << " " << currencyName << " ";
        }
};
#endif
