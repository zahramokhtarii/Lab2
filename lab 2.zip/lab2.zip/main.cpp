
//mokhtari,Zahra

//Tejas, Bhartiya 

//07/8/2022 

//This lab is being solved by a team of people 

//Lab 2 this code is showing  Currency Simulator





#include <iostream>
#include "currency.cpp"
#include "dollar.cpp"
#include "pound.cpp"
using namespace std;

int main()
{
    // declare variables 
    char operationName, currencyChar;
    string currencyName;
    double value;
    // declare an array of 2 Currency pointers
    Currency* currencyPointer[2];
    // Set the first reference in the array to a Pound object
    currencyPointer[0] = new Pound(0.00);
    // Set the second reference to a Dollar object
    currencyPointer[1] = new Dollar(0.00);
    // toString the initial values
    currencyPointer[0]->toString();
    currencyPointer[1]->toString();
    while (true)
    {
        cout << endl;
        // get user input
        cin >> operationName >> currencyChar >> value >> currencyName;
        // check the operation name
        if (operationName == 'a')
        {
            // addition
            if (currencyChar == 'd' && currencyName == "dollar")
                currencyPointer[1]->add(value);
            else if (currencyChar == 'p' && currencyName == "pound")
                currencyPointer[0]->add(value);
            else
                cout << "Invalid addition" << endl;
            currencyPointer[0]->toString();
            currencyPointer[1]->toString();
        } // subtraction
        else if (operationName == 's')
        {
            if (currencyChar == 'd' && currencyName == "dollar")
                currencyPointer[1]->subtract(value);
            else if (currencyChar == 'p' && currencyName == "pound")
                currencyPointer[0]->subtract(value);
            else
                cout << "Invalid subtraction" << endl;
            currencyPointer[0]->toString();
            currencyPointer[1]->toString();
        } // not valid operationName end the program
        else
            break;
    }
    return 0;
}
