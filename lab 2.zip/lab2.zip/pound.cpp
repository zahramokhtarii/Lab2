

//mokhtari,Zahra

//Tejas, Bhartiya 

//07/8/2022 

//This lab is being solved by a team of people 

//Lab 2 this code is showing  Currency Simulator





#ifndef POUND_H
#define POUND_H

#include <iostream>
#include "currency.cpp"
using namespace std;

// // derived class Pound from Currency class
class Pound : public Currency
{
    private:
        string currencyName;
    
    public:
        //constructor
        Pound(double value) : Currency(value)
        {
            currencyName = "Pound";
        }
    
        void toString()
        {
            Currency::toString();
            cout << " " << currencyName << " ";
        }
};
#endif