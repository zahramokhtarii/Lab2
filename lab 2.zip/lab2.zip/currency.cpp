
//mokhtari,Zahra

//Tejas, Bhartiya 

//07/8/2022 

//This lab is being solved by a team of people 

//Lab 2 this code is showing  Currency Simulator





#ifndef CURRENCY_H
#define CURRENCY_H

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// abstract base class called Currency
class Currency
{
    private:
        int whole;
        int fraction;
    
    public:
        // default constructor
        Currency()
        {
            whole = 0;
            fraction = 0;
        }
        // parametered constructor
        Currency(double input)
        {
            if (input < 0)
                throw "Invalid value";
            whole = int(input);
            fraction = (int)round(fabs(input - trunc(input)) * 1e2);
        }
        Currency(const Currency &p1)
        {
            whole = p1.whole;
            fraction = p1.fraction;
        }
        // destructor
        ~Currency()
        {
        }
        // getters
        int getWhole()
        {
            return whole;
        }
    
        int getFraction()
        {
            return fraction;
        }
        
        // setters
        void setWhole(int whole)
        {
            this->whole = whole;
        }
        void setFraction(int fraction)
        {
            this->fraction = fraction;
        }
        
        // adding an input object of the same currency
        void add(double input)
        {
            whole = whole + int(input);
            fraction = fraction + (int)round(fabs(input - trunc(input)) * 1e2);
        }
    
        // subtracting an input object of the same currency
        void subtract(double input)
        {
            int inputwhole = int(input);
            int inputfraction = (int)round(fabs(input - trunc(input)) * 1e2);
            if (whole - inputwhole < 0 || fraction - inputfraction < 0)
            {
                cout << "Invalid subtraction" << endl;
            }
            else
            {
                whole = whole - inputwhole;
                fraction = fraction - inputfraction;
            }
        }
        //  comparing an input object of the same currency for equality/inequality.
        bool isEqual(Currency c1, Currency c2)
        {
            return (c1.whole == c2.whole &&  c1.fraction == c2.fraction);
        }
        //  comparing an input object of the same currency to identify which object is larger or smaller.
        bool isGreater(Currency c1, Currency c2)
        {
            if (c1.whole > c2.whole)
                return true;
            if (c1.fraction == c2.fraction)
            {
                if (c1.fraction > c2.fraction)
                    return true;
                else
                    return false;
            }
            return false;
        }
        // print the name and value of a currency object in the form "xx.yy"
        virtual void toString()
        {
            cout << fixed << setprecision(2);
            cout << getWhole() << '.' << setw(2) << setfill('0') << getFraction();
        }
};
#endif
